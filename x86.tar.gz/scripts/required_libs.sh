#! /bin/sh

#####################################################
#                                                   #
# Install libs required to install AllStar Asterisk #
#                                                   #
#####################################################

apt install libusb-dev -y

apt install libnewt-dev -y

apt install libeditline0 -y

apt install libncurses5-dev -y

apt install bison -y

apt install libssl-dev -y

apt install libasound2-dev -y

apt install libcurl4-gnutls-dev -y

apt install php5-cli -y

apt install libiksemel-dev -y

apt install libvorbis-dev -y

apt install curl -y

# Nice to have utilities and tools

apt install sox -y

apt install usbutils -y

