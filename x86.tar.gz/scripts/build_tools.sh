#! /bin/sh

###################################################
#                                                 #
#    script is for Debian Jessie base install.    #
#                                                 #
###################################################

apt install g++ -y

apt install make -y

apt install build-essential -y

apt install git -y

apt install subversion -y


